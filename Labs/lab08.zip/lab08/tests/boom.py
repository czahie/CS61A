test = {
  'name': 'Boom',
  'points': 0,
  'suites': [
    {
      'type': 'concept',
      'cases': [
        {
          'question': 'What is the order of growth in runtime for boom?',
          'answer': 'n^4',
          'choices': [
            '1', 'n', 'log(n)', 'n^2', 'n^3', 'n^4', 'exponential'
          ]
        },
      ]
    }
  ]
}
